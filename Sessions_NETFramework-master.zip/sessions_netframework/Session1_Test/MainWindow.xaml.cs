﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Session1_Test._src.pages;
using Session1_Test._src.pages.Jury_Moderators;
using Session1_Test._src.pages.Events;
using Session1_Test._src.pages.Organizators;
using System.Windows.Media.Animation;

namespace Session1_Test
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            WindowStartupLocation = WindowStartupLocation.CenterScreen;

            // Основная команда для итоговой работыx
            MainFrameNavigation.Navigate(new MainPage());
        }

        /// <summary>
        ///  TODO: надо сделать изменение размера окна в зависимости от размера страницы
        /// </summary>

        //private void CurrentPage_SizeChanged(object sender, SizeChangedEventArgs e)
        //{
        //    var currentPage = sender as Page;
        //    UpdateMainWindowSize(currentPage);
        //}

        //private void UpdateMainWindowSize(Page page)
        //{
        //    // Выставляем размеры главного окна в соответствии с размерами страницы + отступы
        //    this.Width = page.ActualWidth;
        //    this.Height = page.ActualHeight;
        //}

        //private void MainFrameNavigation_Navigated(object sender, NavigationEventArgs e)
        //{
        //    // Получаем открытую страницу из MainFrameNavigation
        //    var currentPage = MainFrameNavigation.Content as Page;

        //    if (currentPage != null)
        //    {
        //        Title = currentPage.Title;

        //        currentPage.SizeChanged += CurrentPage_SizeChanged;

        //        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        //        return;
        //    }
        //}
    }
}
