﻿using Session1_Test._src.database;
using System.Linq;
using Session1_Test._src.scripts;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Session1_Test._src.pages.Organizators;

namespace Session1_Test._src.pages
{
    /// <summary>
    /// Interaction logic for LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void btLogin_Click(object sender, RoutedEventArgs e)
        {
            int login = int.Parse(tbLogin.Text.Trim());
            string password = pbPassword.Password.Trim();

            Auth(login, password);
        }

        public void Auth(int login, string password)
        {
            var user = Authentication.UserCheck(login, password);

            if (user != null)
            {
                Application.Current.Properties["id_number"] = user.id_number;
                Application.Current.Properties["role"] = GiveRoleUser(user);
                FormsByRole(user);
            } else
                MessageBox.Show("Пользователя не существует! Проверьте на правильность введённых данных!");
        }

        public void FormsByRole(Users user)
        {
            switch (GiveRoleUser(user))
            {
                case Authentication.Roles.Организатор:
                    NavigationService.Navigate(new MainMenuOrganPage());
                    break;
                default:
                    NavigationService.Navigate(new MyProfileOrganPage());
                    break;
            }
        }

        private Authentication.Roles GiveRoleUser(Users user)
        {
            // Чёрная магия, ничего не знаю
            switch (user.id_number.ToString()[0] - 48)
            {
                case 1:
                    return Authentication.Roles.Организатор;
                case int i when i > 1 && i <= 7:
                    return Authentication.Roles.Участник;
                case 8:
                    return Authentication.Roles.Модератор;
                case 9:
                    return Authentication.Roles.Жюри;
                default:
                    MessageBox.Show("Неизвестная ошибка!\nТакой роли не существует!");
                    break;
            }
            return Authentication.Roles.Error;
        }

        private void btCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainPage());
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new RegistrationUserPage());
        }
    }
}
