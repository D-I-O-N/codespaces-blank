﻿using Session1_Test._src.database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.TextFormatting;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Session1_Test._src.pages.Organizators
{
    /// <summary>
    /// Interaction logic for MainMenuOrganPage.xaml
    /// </summary>
    public partial class MainMenuOrganPage : Page
    {
        KonkursDBEntities entities = new KonkursDBEntities();
        private int _id_number = Convert.ToInt32(Application.Current.Properties["id_number"]);

        public MainMenuOrganPage()
        {
            InitializeComponent();

            var user = entities.Users.FirstOrDefault(u => u.id_number == _id_number);

            lblWelcome.Text = GetWelcomeText() + "\n" + genderAndName(user);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MyProfileOrganPage());
        }

        private string genderAndName(Users usr)
        {
            if (usr != null)
            {
                switch (usr.Gender)
                {
                    case "М":
                        return "Mr. " + usr.FIO.Split(' ')[1];
                    case "Ж":
                        return "Ms. " + usr.FIO.Split(' ')[1];
                    default:
                        return "Error";
                }
            }
            return "Error...";
        }

        private int GetCurrentTime()
        {
            var CurTime = DateTime.Now;
            return CurTime.Hour;
        }

        private string GetWelcomeText()
        {
            switch (GetCurrentTime())
            {
                case int i when i >= 0 && i <= 5:
                    return "Доброй ночи!";
                case int i when i > 5 && i <= 11:
                    return "Доброе утро!";
                case int i when i > 11 && i <= 18:
                    return "Добрый день!";
                case int i when i > 18 && i < 24:
                    return "Добрый вечер!";
                default:
                    return "Чаво...";
            }
        }

        private void Logout_Button_Click(object sender, RoutedEventArgs e)
        {
            var dialogResult = MessageBox.Show("Вы уверены, что хотите выйти?", "Выход из учётной записи", MessageBoxButton.YesNo);

            if (dialogResult == MessageBoxResult.Yes)
                NavigationService.Navigate(new LoginPage());
            else if (dialogResult == MessageBoxResult.No)
                return;
        }
    }
}
