﻿using Session1_Test._src.database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Session1_Test._src.pages.Organizators
{
    /// <summary>
    /// Логика взаимодействия для MyProfileOrganPage.xaml
    /// </summary>
    public partial class MyProfileOrganPage : Page
    {
        KonkursDBEntities entities = new KonkursDBEntities();
        private int _id_number = Convert.ToInt32(Application.Current.Properties["id_number"]);
        private string _role = Convert.ToString(Application.Current.Properties["role"]);
        public MyProfileOrganPage()
        {
            InitializeComponent();

            var user = entities.Users.FirstOrDefault(u => u.id_number == _id_number);
            DataContext = user;

            lblGender.Content = GetGenderUser(user);
            lblRole.Content = _role;
        }

        private string GetGenderUser(Users user)
        {
            switch (user.Gender)
            {
                case "М":
                    return "Мужской";
                case "Ж":
                    return "Женский";
                default:
                    return user.Gender;
            }
        }

        private void CheckBox_Click(object sender, RoutedEventArgs e)
        {
            if (cbChangePassword.IsChecked == true)
                spChangePassword.Visibility = Visibility.Visible;
            else if (cbChangePassword.IsChecked == false)
                spChangePassword.Visibility = Visibility.Hidden;
        }

        private void Logout_Button_Click(object sender, RoutedEventArgs e)
        {
            var dialogResult = MessageBox.Show("Вы уверены, что хотите выйти?", "Выход из учётной записи", MessageBoxButton.YesNo);

            if (dialogResult == MessageBoxResult.Yes)
                NavigationService.Navigate(new LoginPage());
            else if (dialogResult == MessageBoxResult.No)
                return;
        }

        private void Back_Button_Click(Object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
