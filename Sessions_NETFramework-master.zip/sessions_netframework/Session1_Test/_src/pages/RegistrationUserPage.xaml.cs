﻿using Session1_Test._src.database;
using Session1_Test._src.scripts;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO.Packaging;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Session1_Test._src.pages
{
    /// <summary>
    /// Interaction logic for RegistrationUserPage.xaml
    /// </summary>
    public partial class RegistrationUserPage : Page
    {
        KonkursDBEntities entities = new KonkursDBEntities();
        public RegistrationUserPage()
        {
            InitializeComponent();

            // id number... Реверсируем запрос и получаем данные
            Users user = entities.Users.OrderByDescending(u => u.id_users).FirstOrDefault();

            // Получаем последний id_number и увеличиваем его на 1
            int id_num = user.id_number;
            id_num += 1;
            tbIdNumber.Text = (id_num).ToString();

            // Инициализация combobox'ов
            cbRoles.ItemsSource = Enum.GetValues(typeof(Authentication.Roles))
                .Cast<Authentication.Roles>()
                .Where(e => e != Authentication.Roles.Error)
                .ToList();
            cbRoles.SelectedIndex = 0;

            // Тырим данные из БД и засовываем в combobox
            var listCountries = from c in entities.Country select c.NameCountry;
            cbCountry.ItemsSource = listCountries.ToList();
            cbCountry.SelectedIndex = 0;

            // Gender combobx
            string[] gender = { "М", "Ж" };
            cbGender.ItemsSource = gender;
            cbGender.SelectedIndex = 0;
        }

        // Берёт наше число и убирает первую цифру.
        public int idNumberWithoutFirstNum(int id)
        {
            string idNumberAsString = id.ToString().Substring(1);
            int newNumber = int.Parse(idNumberAsString);
            return newNumber;
        }

        public int GetIdWithRoles(string id)
        {
            string idWithoutRoles = id;
            Random rndm = new Random();

            switch (cbRoles.SelectedIndex)
            {
                case 0:
                    return int.Parse(1 + idWithoutRoles);
                case 1:
                    return int.Parse(rndm.Next(2, 8) + idWithoutRoles);
                case 2:
                    return int.Parse(8 + idWithoutRoles);
                case 3:
                    return int.Parse(9 + idWithoutRoles);
                default:
                    return int.Parse(idWithoutRoles);
            }
        }

        private void cbRoles_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int ID = idNumberWithoutFirstNum(int.Parse(tbIdNumber.Text));
                ID = GetIdWithRoles(ID.ToString());
            tbIdNumber.Text = ID.ToString();
        }

        private void Logout_Button_Click(object sender, RoutedEventArgs e)
        {
            var dialogResult = MessageBox.Show("Вы уверены, что хотите выйти?", "Выход из учётной записи", MessageBoxButton.YesNo);

            if (dialogResult == MessageBoxResult.Yes)
                NavigationService.Navigate(new LoginPage());
            else if (dialogResult == MessageBoxResult.No)
                return;
        }

        private void Back_Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void TextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9+]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void RegistrationConfirm(object sender, RoutedEventArgs e)
        {
            int id_number = int.Parse(tbIdNumber.Text);
            string FIO = tbFIO.Text;
            string gender = cbGender.Text;
            DateTime datebirth = dpDateBirth.DisplayDate;
            string email = tbEmail.Text;
            string phonenum = mtbPhoneNumber.Text;
            string country = cbCountry.Text;
            string password_1 = PasswordFields.Password;
            string password_2 = AgainPasswordFields.Password;
            string password = null;
            Users newUser = null;

            bool anyVariableIsNotNull = string.IsNullOrWhiteSpace(password_1) ||
                string.IsNullOrWhiteSpace(password_2) ||
                string.IsNullOrWhiteSpace(FIO) ||
                string.IsNullOrWhiteSpace(country) ||
                string.IsNullOrWhiteSpace(email);

            if (!anyVariableIsNotNull)
            {
                if (password_1 != password_2)
                    MessageBox.Show("Пароли не одинаковые!");
                else
                    password = Authentication.CheckPassword(password_1);

                newUser = new Users
                {
                    id_number = id_number,
                    FIO = FIO,
                    Gender = gender,
                    DateBirth = datebirth,
                    Email = email,
                    PhoneNumber = phonenum,
                    id_country = entities.Country.Where(c => c.NameCountry == country).FirstOrDefault().id_country,
                    Password = password
                };

                entities.Users.Add(newUser);
                entities.SaveChangesAsync();

                MessageBox.Show("Успешно зарегестрирован пользователь!");
            }
            else
                MessageBox.Show("Возможно, что у вас пустые данные. Проверьте ещё раз все поля!");

            
        }
    }
}
