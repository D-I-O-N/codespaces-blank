﻿using Session1_Test._src.database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;

namespace Session1_Test._src.scripts
{
    public class Authentication
    {
        public enum Roles
        {
            Организатор,
            Участник,
            Модератор,
            Жюри,
            Error
        }
        public Authentication() { }
        public static Users UserCheck(int login, string password = null)
        {
            KonkursDBEntities entities = new KonkursDBEntities();
            Users user = null;

            if (password != null)
            {
                user = entities.Users.FirstOrDefault(u => u.id_number == login && u.Password == password);
            }
            else
            {
                user = entities.Users.FirstOrDefault(u => u.id_number == login);
            }

            if (user != null)
                return user;
            return null;
        }

        public static string CheckPassword(string password)
        {
            if (string.IsNullOrEmpty(password)) {
                MessageBox.Show("Пустой пароль! Проверьте все поля!");
                return null;
            } else
            {
                var hasNumber = new Regex(@"[0-9]+");
                var hasUpperChar = new Regex(@"[A-Z]+");
                var hasMinimum8Chars = new Regex(@".{8,}");

                bool isValidated = hasNumber.IsMatch(password) && hasUpperChar.IsMatch(password) && hasMinimum8Chars.IsMatch(password);
                if (isValidated)
                    return password;
                else
                {
                    MessageBox.Show("Ваш пароль не соотвествует требованиям!\n" +
                        "Что должно быть:\n" +
                        "1. Цифры;\n" +
                        "2. Одна или несколько букв в капсе;\n" +
                        "3. Пароль должен иметь длину в 8 символов.");
                    return null;
                }
            }
        }
    }
}
