﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Session1_Test._src.scripts;
using Session1_Test._src.database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session1_Test._src.scripts.Tests
{
    [TestClass()]
    public class AuthenticationTests
    {
        [TestMethod()]
        public void UserCheckTest_ReturnTrue()
        {
            Session1_TestEntities entities = new Session1_TestEntities();
            int login = 110001;
            string password = "421743459\r\n";

            Users exceptedUser = entities.Users.FirstOrDefault(u => u.id_number == login && u.Password == password);
            Users actual = Authentication.UserCheck(login, password);

            Assert.AreEqual(exceptedUser, actual);
        }

        [TestMethod()]
        public void UserCheckTest_ReturnFalse()
        {
            Session1_TestEntities entities = new Session1_TestEntities();
            int login = 110001;
            string password = "421743459";

            Users exceptedUser = entities.Users.FirstOrDefault(u => u.id_number == login && u.Password == password);
            Users actual = Authentication.UserCheck(login, password);

            Assert.AreNotEqual(exceptedUser, actual);
        }

        [TestMethod()]
        public void UserCheckTest_IfUserExist()
        {
            Session1_TestEntities entities = new Session1_TestEntities();
            int login = 110001;

            Users exceptedUser = entities.Users.FirstOrDefault(u => u.id_number == login);
            Users actual = Authentication.UserCheck(login);

            Assert.AreNotEqual(exceptedUser, actual);
        }
    }
}